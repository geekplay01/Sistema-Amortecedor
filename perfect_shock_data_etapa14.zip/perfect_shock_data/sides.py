"""Módulo Lados: para cada item do catálogo, o lado (direito/esquerdo/ambos), o eixo, o par do outro lado e — pela aplicação (veículos do catálogo completo) —
o código do amortecedor traseiro correspondente (e, nos traseiros, o dianteiro)."""
import re, unicodedata
import database as db
from queries import q, q1

SIDE = {"direito": "Direito (LD)", "esquerdo": "Esquerdo (LE)", "ambos": "Ambos (LD/LE)"}
def _up(t): return unicodedata.normalize("NFKD", str(t or "")).encode("ascii", "ignore").decode().upper()
def _axle(desc):
    d = _up(desc)
    if "DIANTEIRO/TRASEIRO" in d or "DIANT" in d and "TRAS" in d: return "ambos_eixos"
    if "DIANT" in d: return "dianteiro"
    if "TRAS" in d: return "traseiro"
    if "CABINE" in d: return "cabine"
    return None
def _status(desc):
    d = _up(desc); return "inativo" if "INATIVO" in d else "em_breve" if "EM BREVE" in d else "ativo"
def _mkey(model):   # 'DOBLO (EXCETO CARGO/ ADVENTURE)' -> 'DOBLO (EXCETO CARGO/ ADVENTURE)' sem ruído de espaços/pontuação
    return re.sub(r"[^A-Z0-9()/ .+-]", "", re.sub(r"\s+", " ", _up(model))).strip()
def _first(model):
    t = re.findall(r"[A-Z0-9]+", _up(model)); return t[0] if t else ""
def _overlap(a1, a2, b1, b2):
    if None in (a1, a2, b1, b2): return True
    return a1 <= b2 and b1 <= a2

def build():
    prods = {p["id"]: p for p in q("SELECT id,perfect_code,description,catalog_position FROM products WHERE catalog_position IS NOT NULL")}
    veh = {}
    for v in q("SELECT product_id,make,model,year_from,year_to,raw FROM catalog_vehicles"): veh.setdefault(v["product_id"], []).append(v)
    pairs = {}
    for r in q("SELECT right_product_id r,left_product_id l FROM side_pairs"): pairs[r["r"]] = (r["l"], "esquerdo"); pairs[r["l"]] = (r["r"], "direito")
    # ESCOPO: só itens do CATÁLOGO (planilha CatalogoAMD) — produtos fora dela não entram nem como candidatos a par/traseiro
    items = {}
    for pid, p in prods.items():
        d = p["description"]; sd = db.side_from_text(d)
        if sd is None: sd = db.side_from_text(" ; ".join(str(v["raw"] or "") for v in veh.get(pid, [])))      # sem lado na descrição: procura na Aplicação do catálogo
        items[pid] = {"id": pid, "code": p["perfect_code"], "description": d, "axle": _axle(d), "side": sd, "status": _status(d), "vehicles": veh.get(pid, []), "pair": None, "pair_how": None, "rear": [], "front": []}
    for pid, it in items.items():   # par do outro lado: planilha Lados; senão, mesma aplicação e eixo com lado oposto
        if pid in pairs: o = items.get(pairs[pid][0]); it["pair"] = o and {"id": o["id"], "code": o["code"], "side": o["side"]}; it["pair_how"] = "planilha Lados"
    idx_exact, idx_first = {}, {}
    for pid, it in items.items():
        for v in it["vehicles"]:
            idx_exact.setdefault((it["axle"], v["make"], _mkey(v["model"])), []).append((pid, v["year_from"], v["year_to"]))
            idx_first.setdefault((it["axle"], v["make"], _first(v["model"])), []).append((pid, v["year_from"], v["year_to"]))
    # par por aplicação (quando a planilha Lados não cobre): mesmo eixo/aplicação, lado oposto
    for pid, it in items.items():
        if it["pair"] or it["side"] not in ("direito", "esquerdo") or not it["axle"]: continue
        opp = "esquerdo" if it["side"] == "direito" else "direito"; found = {}
        for v in it["vehicles"]:
            for o, y1, y2 in idx_exact.get((it["axle"], v["make"], _mkey(v["model"])), []):
                if o != pid and items[o]["side"] == opp and items[o]["status"] == it["status"] and _overlap(v["year_from"], v["year_to"], y1, y2): found[o] = found.get(o, 0) + 1
        if found:
            o = items[max(found, key=found.get)]; it["pair"] = {"id": o["id"], "code": o["code"], "side": o["side"]}; it["pair_how"] = "mesma aplicação"
    def match(it, want_axle):
        """códigos do outro eixo com a mesma aplicação: 'exata' (mesmo texto de modelo e anos que se cruzam) ou 'provavel' (mesmo modelo-base e anos)."""
        res = {}
        for v in it["vehicles"]:
            ex = [(o, y1, y2) for o, y1, y2 in idx_exact.get((want_axle, v["make"], _mkey(v["model"])), []) if _overlap(v["year_from"], v["year_to"], y1, y2)]
            for o, *_ in ex: res[o] = "exata"
            if not ex:
                for o, y1, y2 in idx_first.get((want_axle, v["make"], _first(v["model"])), []):
                    if _overlap(v["year_from"], v["year_to"], y1, y2) and o not in res: res[o] = "provavel"
        out = []
        for o, lvl in res.items():
            t = items[o]
            if it["side"] in ("direito", "esquerdo") and t["side"] in ("direito", "esquerdo") and t["side"] != it["side"]: continue   # LD casa com LD (ou par LD/LE)
            if t["status"] == "inativo" and it["status"] != "inativo": continue
            out.append({"id": o, "code": t["code"], "side": t["side"], "level": lvl, "description": t["description"]})
        ex = [x for x in out if x["level"] == "exata"]
        return sorted(ex or out, key=lambda x: (x["level"] != "exata", x["code"]))
    for pid, it in items.items():
        if it["axle"] == "dianteiro": it["rear"] = match(it, "traseiro")
        elif it["axle"] == "traseiro": it["front"] = match(it, "dianteiro")
        other = it["rear"] if it["axle"] == "dianteiro" else it["front"] if it["axle"] == "traseiro" else []
        it["has_vehicles"] = bool(it["vehicles"])
        it["other_axle"] = "nao_se_aplica" if it["axle"] not in ("dianteiro", "traseiro") else ("exata" if any(x["level"] == "exata" for x in other) else "provavel" if other else ("sem_aplicacao" if not it["vehicles"] else "nao"))
    return items

def has_sides(i): return i["side"] in ("direito", "esquerdo")      # «possui lados»: o catálogo separa LD e LE (descrição «LD» ou «LE»); LD/LE juntos = um item só, sem lados

def listing(f):
    items = [i for i in build().values() if has_sides(i)]; term = (f.get("q") or "").upper().split()
    def ok(i):
        if term:
            txt = f"{i['code']} {i['description'] or ''} " + " ".join(v["raw"] or "" for v in i["vehicles"]).upper() + " " + " ".join(r["code"] for r in i["rear"] + i["front"])
            if any(t not in txt.upper() for t in term): return False
        if f.get("axle") and i["axle"] != f["axle"]: return False
        if f.get("side") and i["side"] != f["side"]: return False
        if f.get("pair") == "sem" and (i["pair"] or i["side"] not in ("direito", "esquerdo")): return False
        if f.get("pair") == "com" and not i["pair"]: return False
        if f.get("rear") == "sem" and not (i["axle"] == "dianteiro" and not i["rear"]): return False
        if f.get("rear") == "com" and not i["rear"]: return False
        if f.get("other") and i["other_axle"] != f["other"]: return False
        if f.get("status") and i["status"] != f["status"]: return False
        return True
    rows = sorted((i for i in items if ok(i)), key=lambda i: (i["code"] or ""))
    stats = {"total": len(items), "dianteiro": sum(i["axle"] == "dianteiro" for i in items), "traseiro": sum(i["axle"] == "traseiro" for i in items), "com_traseiro": sum(1 for i in items if i["rear"]),
             "dianteiro_sem_traseiro": sum(1 for i in items if i["axle"] == "dianteiro" and not i["rear"] and i["status"] == "ativo"), "sem_par": sum(1 for i in items if not i["pair"]),
             "traseiro_exato": sum(1 for i in items if i["axle"] == "dianteiro" and i["other_axle"] == "exata"), "traseiro_provavel": sum(1 for i in items if i["axle"] == "dianteiro" and i["other_axle"] == "provavel"),
             "traseiro_nao": sum(1 for i in items if i["axle"] == "dianteiro" and i["other_axle"] == "nao"), "sem_aplicacao": sum(1 for i in items if i["other_axle"] == "sem_aplicacao")}
    size = 50 if not f.get("all") else 10**9; page = max(1, int(f.get("page") or 1))
    out = []
    for i in rows[(page - 1) * size: page * size]:
        j = dict(i); j["vehicles"] = [v["raw"] for v in i["vehicles"]]; out.append(j)
    return {"total": len(rows), "page": page, "size": size, "rows": out, "stats": stats}
