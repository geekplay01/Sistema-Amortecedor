"""LEAD TIME dos pedidos de compra de amortecedor: pedido → embarque → previsão de chegada → recebimento, por fornecedor.

Objetivo do negócio: a estratégia é 6 MESES (180 dias) para amortecedores; este módulo mede o que o fornecedor REALMENTE entrega para identificar quem está «enrolando».
Fonte: PEDIDOS_COMPRA_DETALHADO (ds_compras) + EMBARQUES_DETALHADO (ds_embarques, quando o servidor a tiver) + histórico das datas previstas (po_due_history, gravado a cada sincronização).
Só pedidos EMITIDOS no ano vigente (filtro no SQL). Mesmo universo da tela Pedidos em Aberto: descrição «amortecedor» e código «MP-»; fornecedor traduzido do código EX (ZS / E-WIN / XGM / VERIFICAR).
Métricas (dias corridos, por linha de pedido):
  prazo_prometido  = DATA_PREV_ENT − DATA_EMISSAO_PC          (o que o fornecedor prometeu)
  ate_embarque     = embarque − emissão                          (pedido → embarque)
  transito         = previsão de chegada − embarque              (embarque → previsão para chegar)
  prazo_real       = recebimento/chegada − emissão               (só pedidos já entregues)
  atraso           = recebimento/chegada − DATA_PREV_ENT         (>0 = chegou depois do prometido)
Sinais de alerta: prometido acima da meta · previsão já vencida (aberto) · previsão empurrada (adiada) em sincronizações anteriores · atraso histórico."""
import datetime
import pandas as pd
import orders, rules

DEFAULT_META = 180

def meta_dias():
    try: v = int(float(rules._setting("leadtime_meta_dias") or DEFAULT_META))
    except (TypeError, ValueError): v = DEFAULT_META
    return v if 30 <= v <= 720 else DEFAULT_META

def _ensure(c):
    c.execute("CREATE TABLE IF NOT EXISTS po_due_history(id INTEGER PRIMARY KEY, pedido TEXT NOT NULL, code TEXT NOT NULL, due_date TEXT, seen_at TEXT NOT NULL, baseline INTEGER DEFAULT 0)")
    c.execute("CREATE INDEX IF NOT EXISTS ix_pdh ON po_due_history(pedido, code, id)")

def snapshot_due(today=None):
    """Chamada a cada sincronização: grava a DATA_PREV_ENT de cada linha de pedido quando ela muda (a 1ª gravação é o marco zero). Devolve quantas mudanças registrou."""
    import database as db
    c = db.conn(); at = (today or datetime.date.today()).isoformat()
    try:
        _ensure(c); first = c.execute("SELECT COUNT(*) FROM po_due_history").fetchone()[0] == 0
        last = {(r[0], r[1]): r[2] for r in c.execute("SELECT pedido, code, due_date FROM po_due_history WHERE id IN (SELECT MAX(id) FROM po_due_history GROUP BY pedido, code)")}
        new = [(p, k, d, at, 1 if first else 0) for p, k, d in c.execute("SELECT pedido, upper(code), due_date FROM ds_compras WHERE pedido IS NOT NULL AND code IS NOT NULL")
               if (str(p), k) not in last or last[(str(p), k)] != d]
        c.executemany("INSERT INTO po_due_history(pedido, code, due_date, seen_at, baseline) VALUES(?,?,?,?,?)", [(str(p), k, d, a, b) for p, k, d, a, b in new]); c.commit()
        return len(new)
    finally: c.close()

def _d(s): return pd.to_datetime(s, errors="coerce")
def _days(a, b): return (b - a).dt.days                    # b − a em dias (NaN se faltar alguma data)

def _stats(s):
    s = pd.to_numeric(s, errors="coerce").dropna()
    return {"n": int(len(s)), "media": None, "mediana": None, "p90": None, "max": None} if s.empty else {"n": int(len(s)), "media": round(float(s.mean()), 1), "mediana": round(float(s.median()), 1), "p90": round(float(s.quantile(.9)), 1), "max": int(s.max())}

def frame(today=None):
    """DataFrame com uma linha por (pedido, código) já com as métricas. Vazio se não houver compras sincronizadas.
    Usa só as linhas do universo (MP- + amortecedor), pré-filtradas no SQL — nunca o histórico inteiro de compras."""
    from queries import q
    from analytics import _has
    if not _has("ds_compras"): return None
    ano = (today or datetime.date.today()).year                      # ANO VIGENTE: só pedidos emitidos neste ano, filtrados já no SQL (poupa memória)
    df = orders.pedidos_em_aberto(orders.load(only_open=False, year=ano), only_open=False)
    rec = pd.DataFrame(q("SELECT upper(code) codigo, COALESCE(pedido,'') numero_pedido, MAX(received_date) received_date FROM ds_compras WHERE upper(code) LIKE 'MP-%' AND substr(order_date, 1, 4) = ? GROUP BY 1, 2", (f"{ano:04d}",)))
    df = df.merge(rec, on=["codigo", "numero_pedido"], how="left") if len(rec) else df.assign(received_date=None)
    df["emissao"], df["prevista"], df["recebido"] = _d(df["DATA_EMISSAO_PC"]), _d(df["DATA_PREV_ENT"]), _d(df["received_date"])
    df["embarque"] = pd.NaT; df["chegada_prev"] = pd.NaT; df["chegada"] = pd.NaT
    try:
        e = pd.DataFrame(q("SELECT COALESCE(pedido,'') pedido, upper(code) code, MIN(ship_date) ship, MAX(eta_date) eta, MAX(arrival_date) arr FROM ds_embarques GROUP BY 1, 2"))
    except Exception: e = pd.DataFrame()
    df.attrs["has_embarques"] = not e.empty
    if not e.empty:
        m = df.merge(e, left_on=["numero_pedido", "codigo"], right_on=["pedido", "code"], how="left")      # (pedido, código); senão só pelo pedido
        e2 = e.groupby("pedido").agg(ship=("ship", "min"), eta=("eta", "max"), arr=("arr", "max")).reset_index()
        m = m.merge(e2, left_on="numero_pedido", right_on="pedido", how="left", suffixes=("", "_p"))
        for a, b in (("ship", "ship_p"), ("eta", "eta_p"), ("arr", "arr_p")): m[a] = m[a].where(m[a].notna(), m[b])
        df["embarque"], df["chegada_prev"], df["chegada"] = _d(m["ship"]).values, _d(m["eta"]).values, _d(m["arr"]).values
    fim = df["recebido"].where(df["recebido"].notna(), df["chegada"])
    df["prazo_prometido"] = _days(df["emissao"], df["prevista"]); df["ate_embarque"] = _days(df["emissao"], df["embarque"])
    df["transito"] = _days(df["embarque"], df["chegada_prev"].where(df["chegada_prev"].notna(), df["prevista"]))
    df["prazo_real"] = _days(df["emissao"], fim); df["atraso"] = _days(df["prevista"], fim)
    hoje = pd.Timestamp(today or datetime.date.today()); df["idade"] = (hoje - df["emissao"]).dt.days
    df["vencida"] = df["em_aberto"] & df["prevista"].notna() & (df["prevista"] < hoje); df["dias_vencida"] = (hoje - df["prevista"]).dt.days.where(df["vencida"])
    df["entregue"] = fim.notna() | ~df["em_aberto"]
    return df

def _pushes():
    """{(pedido, código): {'vezes': n, 'dias': total empurrado}} a partir do histórico de previsões (ignora o marco zero)."""
    from queries import q
    try: h = pd.DataFrame(q("SELECT pedido, code, due_date, baseline FROM po_due_history ORDER BY id"))
    except Exception: return None
    if h.empty: return {}
    h["d"] = _d(h["due_date"]); out = {}
    for (p, k), g in h.groupby(["pedido", "code"]):
        g = g.dropna(subset=["d"]); v, dias, prev = 0, 0, None
        for d in g["d"]:
            if prev is not None and d > prev: v += 1; dias += int((d - prev).days)
            prev = d
        if v: out[(p, k)] = {"vezes": v, "dias": dias}
    return out

_C = {}
def payload(today=None):
    """Resultado em cache até a próxima sincronização (ou virada do dia): abrir a tela repetidamente não recalcula nada."""
    from queries import q1
    def n(t):
        try: return (q1(f"SELECT COUNT(*) n FROM {t}") or {}).get("n")
        except Exception: return None
    k = (orders._stamp(), n("po_due_history"), n("ds_embarques"), str(today or datetime.date.today()), meta_dias())
    if k is not None and _C.get("k") == k: return _C["v"]
    v = _payload(today)
    if k is not None: _C["k"], _C["v"] = k, v
    return v

def _payload(today=None):
    df = frame(today)
    if df is None or df.empty: return {"available": False}
    meta = meta_dias(); push = _pushes(); df["adiada_vezes"] = 0; df["adiada_dias"] = 0
    if push:
        df["adiada_vezes"] = [push.get((r.numero_pedido, r.codigo), {}).get("vezes", 0) for r in df.itertuples()]; df["adiada_dias"] = [push.get((r.numero_pedido, r.codigo), {}).get("dias", 0) for r in df.itertuples()]
    df["acima_meta"] = df["prazo_prometido"] > meta
    def alerts(r):
        a = []
        if r.acima_meta: a.append(f"prometido em {int(r.prazo_prometido)} dias (meta {meta})")
        if r.vencida: a.append(f"previsão vencida há {int(r.dias_vencida)} dias")
        if r.adiada_vezes: a.append(f"previsão adiada {int(r.adiada_vezes)}× (+{int(r.adiada_dias)} dias)")
        if r.em_aberto and pd.isna(r.embarque) and df.attrs.get("has_embarques") and pd.notna(r.idade) and r.idade > meta * 0.6: a.append(f"sem embarque há {int(r.idade)} dias")
        if pd.notna(r.atraso) and r.atraso > 0 and not r.em_aberto: a.append(f"chegou {int(r.atraso)} dias após o prometido")
        return a
    df["alertas"] = [alerts(r) for r in df.itertuples()]
    def block(g):
        ab = g[g["em_aberto"]]
        return {"linhas": int(len(g)), "em_aberto": int(len(ab)), "pedidos": int(g["numero_pedido"].nunique()),
                "prazo_prometido": _stats(g["prazo_prometido"]), "ate_embarque": _stats(g["ate_embarque"]), "transito": _stats(g["transito"]), "prazo_real": _stats(g["prazo_real"]), "atraso": _stats(g["atraso"]),
                "acima_meta": int(g["acima_meta"].sum()), "pct_acima_meta": round(100 * float(g["acima_meta"].mean()), 1) if len(g) else None,
                "vencidas": int(ab["vencida"].sum()), "adiadas": int((g["adiada_vezes"] > 0).sum()), "adiamento_medio_dias": round(float(g.loc[g["adiada_vezes"] > 0, "adiada_dias"].mean()), 1) if (g["adiada_vezes"] > 0).any() else None,
                "sem_embarque": int(ab["embarque"].isna().sum()) if df.attrs.get("has_embarques") else None,
                "no_prazo_pct": round(100 * float((g["atraso"].dropna() <= 0).mean()), 1) if g["atraso"].notna().any() else None}
    por = [{"fornecedor": f, **block(g)} for f, g in df.groupby("fornecedor")]
    bins = [(-10**6, 90, "até 90 dias"), (90, 180, "91 a 180"), (180, 270, "181 a 270"), (270, 10**6, "mais de 270")]
    dist = [{"faixa": l, "n": int(((df["prazo_prometido"] > a) & (df["prazo_prometido"] <= b)).sum())} for a, b, l in bins]
    cols = ["codigo", "numero_pedido", "fornecedor", "STATUS_PC", "DATA_EMISSAO_PC", "DATA_PREV_ENT", "quantidade", "prazo_prometido", "ate_embarque", "transito", "idade", "adiada_vezes", "alertas"]
    ab = df[df["em_aberto"]].copy()
    ab["_n"] = ab["alertas"].map(len); ab = ab.sort_values(["_n", "idade"], ascending=False)
    lin = ab[cols].astype(object).where(ab[cols].notna(), None).to_dict("records")
    for r in lin:
        for k in ("prazo_prometido", "ate_embarque", "transito", "idade", "adiada_vezes"): r[k] = None if r[k] is None else int(r[k])
        r["quantidade"] = None if r["quantidade"] is None else float(r["quantidade"])
    return {"available": True, "meta_dias": meta, "tem_embarques": bool(df.attrs.get("has_embarques")), "tem_historico": push is not None and bool(push or _has_hist()),
            "geral": block(df), "por_fornecedor": por, "distribuicao": dist, "linhas": lin[:300], "linhas_total": int(len(ab))}

def _has_hist():
    from queries import q1
    try: return (q1("SELECT COUNT(*) n FROM po_due_history") or {"n": 0})["n"] > 0
    except Exception: return False
